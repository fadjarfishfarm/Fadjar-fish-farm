# Fadjar Fish Farm — Aplikasi Android (PWA)

## Cara pakai (V1)
1. Install Node.js, lalu di folder ini jalankan:
   `npm install` lalu `npm run build`
2. Upload isi folder `dist` ke hosting HTTPS gratis, mis. Netlify Drop (app.netlify.com/drop) atau Vercel.
3. Di HP Android, buka alamat hasil hosting di Chrome → menu ⋮ → **Instal aplikasi** (atau *Tambahkan ke layar utama*).

Ikon "Fadjar Fish Farm" akan muncul di layar utama dan aplikasi terbuka layar penuh tanpa bilah alamat.

## Catatan
- Data tersimpan di HP itu sendiri (localStorage). HP lain atau browser lain tidak berbagi data, dan data bisa hilang bila data browser dihapus.
- Untuk uji di komputer: `npm run dev`.

## Hosting lewat GitHub Pages
1. Buat repository **public** di GitHub, upload semua isi folder ini (termasuk `.github/workflows/deploy.yml`).
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. Tunggu tab Actions selesai (centang hijau). Alamat: `https://USERNAME.github.io/NAMA-REPO/`
4. Buka alamat itu di Chrome Android → ⋮ → Instal aplikasi.
