import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" supaya aplikasi bisa di-hosting di folder/alamat mana pun
export default defineConfig({ base: "./", plugins: [react()] });
